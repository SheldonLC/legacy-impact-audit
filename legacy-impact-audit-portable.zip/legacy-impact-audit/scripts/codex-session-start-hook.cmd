@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "FALLBACK={\"decision\":\"proceed\",\"hookSpecificOutput\":{\"hookEventName\":\"SessionStart\",\"additionalContext\":\"Legacy Impact Audit fallback active: Python unavailable or hook execution failed. Run legacy-impact-audit manually before code changes.\"}}"

where python >nul 2>nul
if errorlevel 1 (
  echo %FALLBACK%
  exit /b 0
)

set "HOOK_OUTPUT="
for /f "usebackq delims=" %%I in (`python "%SCRIPT_DIR%codex-session-start-hook.py" 2^>nul`) do set "HOOK_OUTPUT=%%I"

if not defined HOOK_OUTPUT (
  echo %FALLBACK%
  exit /b 0
)

echo %HOOK_OUTPUT%
exit /b 0
