#!/usr/bin/env sh
set -eu

case "$0" in
  */*) SCRIPT_PATH=$0 ;;
  *) SCRIPT_PATH=./$0 ;;
esac
SCRIPT_DIR=$(CDPATH= cd -- "${SCRIPT_PATH%/*}" && pwd)
FALLBACK='{"decision":"proceed","hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":"Legacy Impact Audit fallback active: Python unavailable or hook execution failed. Run legacy-impact-audit manually before code changes."}}'

if command -v python3 >/dev/null 2>&1; then
  PYTHON=python3
elif command -v python >/dev/null 2>&1; then
  PYTHON=python
else
  printf '%s\n' "$FALLBACK"
  exit 0
fi

OUTPUT=$("$PYTHON" "$SCRIPT_DIR/codex-session-start-hook.py" 2>/dev/null || true)

case "$OUTPUT" in
  \{*\})
    printf '%s\n' "$OUTPUT"
    ;;
  *)
    printf '%s\n' "$FALLBACK"
    ;;
esac
